/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "rtc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "atk_ms6050.h"
#include "inv_mpu.h"
#include "oled.h"
#include "bme280.h"
#include "uart.h"
#include "time.h"
#include "EEPROM.h"
#include "key.h"
#include "json.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
     /* ϵͳ��Ҫ */
const uint8_t mode_5[4]={0x15,0x05,0x1A,0x0D};
uint8_t System_Delay=0; 
uint8_t Date_array[32]=0; 
uint8_t Stime_array[32]=0; 
uint8_t Oled_array[50]={0};
uint8_t addr_temp[2]=0;
uint16_t addr=0;
uint8_t Stor_array[5];
uint32_t unix=0;
		/* ������� */
uint8_t Ret_Flag=0;                              //��ȡ������
uint8_t Error_flag=0;
double Acc_err=0.0,Acc_num=0.0,Max_acc=8.0f;
double old_high=0.0,now_high=0.0,pre_high=0.0,Imp_high=0.0;
float pitch=0.0,roll=0.0,yaw=0.0;
float Err_pitch=0.0,Err_roll=0.0,Err_yaw=0.0;
float ax=0.0, ay=0.0, az=0.0;
float Err_ax=0.0, Err_ay=0.0, Err_az=0.0;
float Realy_ax=0.0, Realy_ay=0.0, Realy_az=0.0,SVM=0.0;
float alpha = 0.9f;
static float ax_filt = 0, ay_filt = 0, az_filt = 0;
uint8_t Danger_flag=0,Diedao_flag=0;
uint8_t i=0;
uint8_t high_hr=0,low_hr=0;
uint8_t hr_flag=0;
rtc_time_t temp_time={0};
BMP_CONFIG Temp_conf={0x02,0x02,0x00};
uint8_t Acc_flag=0,Pre_flag=0; 											//�¶�
uint8_t use_num=0,Mode_flag=0,HR_flag=0,all_flag=0,stop_flag=0,re_flag=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_I2C3_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */
	/* ��ʼ������ Begin */
{
	OLED_Init();	
	OLED_Clear();
	HAL_UART_Receive_IT(&huart2,&Uart2_rx_data_buffer, 1);       //�������ڽ��ճ�ʼ��
	HAL_UART_Receive_IT(&huart1,&Uart1_rx_data_buffer, 1); 
	HAL_UART_Transmit(&huart1,mode_5,sizeof(mode_5),2000);
}
	/* ��ʼ������ End */

	/* ��ʼ��MPU6050Ӳ�����Լ� Begin */
{
	Ret_Flag = atk_ms6050_init();  	    																			
	while (Ret_Flag != 0)
	{
		Error_flag=1;                
		Error_Handler();
	}
	/* ��ʼ�� ATK-MS6050 DMP */
	Ret_Flag = atk_ms6050_dmp_init(); 
	/* �������Լ� Begin */
{
	if(EEPROM_Check(&iic3,EEPROM_DEV_ADDR3,0x07FF)==1)
	{
		Error_flag=3;                
		Error_Handler();
	}
}
	/* �������Լ� End */
	
	Bmp_Init();//BME280��ʼ��
	if (BMP280_ReadID()!=0x60) {
		Error_flag=4;                
		Error_Handler();
    }
	atk_ms6050_get_accelerometer(&Err_ax, &Err_ay, &Err_az);
	atk_ms6050_dmp_get_data(&Err_pitch,&Err_roll,&Err_yaw);
}
	/* ��ʼ��MPU6050Ӳ�����Լ� End */
	
	/* ��������ʼ�� Begin */
{

	HAL_TIM_Base_Start_IT(&htim3);                          //������ʱ��	
}

	/* ��������ʼ�� End */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		use_num=Key_GetNum();
		if(high_hr==0)high_hr=HR;
		if(low_hr==0)low_hr=HR;
		if(high_hr<HR)high_hr=HR;
		if(low_hr>HR)low_hr=HR;
/* -------------------------------------------��ֵ����-----------------------------------------*/
		if(use_num==1)       //ģʽ�л�
		{
		 Mode_flag++;
		 if(Mode_flag>3)Mode_flag=0;
		 OLED_Clear();
		}
		if(use_num==2)
		{
			HAL_UART_Transmit(&huart1,stop_epc,sizeof(stop_epc),2000);
      OLED_Clear();			
     	all_flag=0;		
		}
		
		if(use_num==4)	 
		{
		  HAL_UART_Transmit(&huart1,start_epc,sizeof(start_epc),2000);	
			OLED_Clear();
      all_flag=1;					
		}
		if(stop_flag==1)
		{
			HAL_UART_Transmit(&huart1,stop_epc,sizeof(stop_epc),2000);
      OLED_Clear();			
     	all_flag=0;	
      stop_flag=0;			
		}

		/* ����������������������������������������������������ʱ��У׼-�������������������������������������������������������� */

	 if(Uart2_deal_flag==1){
		  Uart2_deal_flag=0;
			Get_time(Time_array);
		 	HAL_RTC_GetTime(&hrtc, &rtc_time_struct, RTC_FORMAT_BIN);
		  HAL_RTC_GetDate(&hrtc, &rtc_date_struct, RTC_FORMAT_BIN);//��ȡRTCʱ��
	    memset(Date_array, 0x00, sizeof(Date_array));   
		 sprintf((char*)Date_array, ": 20%02d-%02d-%02d", 
				rtc_date_struct.Year,rtc_date_struct.Month, rtc_date_struct.Date);  //��ʱ����룬׼����ʾ	
			memset(Stime_array, 0x00, sizeof(Stime_array));   
		 sprintf((char*)Stime_array, ": %02d:%02d  ", 
				rtc_time_struct.Hours,rtc_time_struct.Minutes);                     //��ʱ����룬׼����ʾ	
		}
	 if(Uart2_deal_flag==2){         //json���ݽ���
			json_analysis_and_display_time();
			Uart2_deal_flag=0;
	    OLED_Clear();	  
		}	
	 if(System_Delay==30)             //ÿ��30sͨ��RTCУ׼ʱ��
	 {
		  HAL_RTC_GetTime(&hrtc, &rtc_time_struct, RTC_FORMAT_BIN);
		  HAL_RTC_GetDate(&hrtc, &rtc_date_struct, RTC_FORMAT_BIN); 
		 sprintf((char*)Date_array, ": 20%02d-%02d-%02d", 
				rtc_date_struct.Year,rtc_date_struct.Month, rtc_date_struct.Date);             //��ʱ����룬׼����ʾ	  
		 sprintf((char*)Stime_array, ": %02d:%02d  ", 
				rtc_time_struct.Hours,rtc_time_struct.Minutes); 
		 System_Delay=0;
	 }
/*-----------------------------------------------OLED��ʾ-----------------------------------------------------*/
if(all_flag==0)	
{
if(Mode_flag==0)               //������ʾ
	{	 
		 OLED_ShowHanzi(0,0,0);
		 OLED_ShowHanzi(16,0,1);
		 OLED_ShowStr(32,0,Date_array,16);
		 OLED_ShowHanzi(0,2,2);
		 OLED_ShowHanzi(16,2,3);
		 OLED_ShowStr(32,2,Stime_array,16);
	}
	if(Mode_flag==1)        //��ҩʱ����ʾ
	{	 	
  	if(n==2)
		{
		memset(Oled_array, 0x00, sizeof(Oled_array));
    sprintf((char*)Oled_array, "> %02d:%02d - %02d", t1h, t1m, n1);
		OLED_ShowStr(0,0,Oled_array,16);
    memset(Oled_array, 0x00, sizeof(Oled_array));
    sprintf((char*)Oled_array, "> %02d:%02d - %02d", t2h, t2m, n2);	
		OLED_ShowStr(0,2,Oled_array,16);
		}
		else if(n==3)
		{
		memset(Oled_array, 0x00, sizeof(Oled_array));
    sprintf((char*)Oled_array, "> %02d:%02d - %02d", t1h, t1m, n1);
		OLED_ShowStr(0,1,Oled_array,8);
    memset(Oled_array, 0x00, sizeof(Oled_array));
    sprintf((char*)Oled_array, "> %02d:%02d - %02d", t2h, t2m, n2);
	  OLED_ShowStr(0,2,Oled_array,8);
    memset(Oled_array, 0x00, sizeof(Oled_array));
    sprintf((char*)Oled_array, "> %02d:%02d - %02d", t3h, t3m, n3);		
		OLED_ShowStr(0,3,Oled_array,8);			
		}
		else
		{
			OLED_ShowChar(0,2,'>',8);
			OLED_ShowChar(0,3,'>',8);
		}
	}
	if(Mode_flag==2)     //������ʾ
	{	 
		if(use_num==3)
		{
		 HR_flag++;
		 if(HR_flag>2)HR_flag=0;
		OLED_Clear();
		}
		if(HR_flag==0)     //��ǰ���
		{
			OLED_ShowHanzi(0,0,4);
		  OLED_ShowHanzi(16,0,5);	
			if(hr_flag==1)
			{
			OLED_ShowHanzi(32,0,6);
		  OLED_ShowHanzi(48,0,19);					
			}
			if(hr_flag==2)
			{
			OLED_ShowHanzi(32,0,6);
		  OLED_ShowHanzi(48,0,20);					
			}
			if(hr_flag==3)
			{
			OLED_ShowHanzi(32,0,13);
		  OLED_ShowHanzi(48,0,14);					
			}
			else
			{
			OLED_ShowHanzi(32,0,15);
		  OLED_ShowHanzi(48,0,14);						
			}
			if(FAG==2)
		 {
			 //���ƣ��
			  OLED_ShowHanzi(0,2,7);
			  OLED_ShowHanzi(16,2,8);
			  OLED_ShowHanzi(32,2,9);
			  OLED_ShowHanzi(48,2,10);
		 }
		  else if(FAG==3)
		 {
			 //����ƣ��
			  OLED_ShowHanzi(0,2,11);
			  OLED_ShowHanzi(16,2,12);
			  OLED_ShowHanzi(32,2,9);
			  OLED_ShowHanzi(48,2,10);
		 }
		 else
		 {
			 	OLED_ShowHanzi(0,2,21);
			  OLED_ShowHanzi(16,2,22);
			  OLED_ShowHanzi(32,2,23);
			  OLED_ShowHanzi(48,2,23);
		 }
		}
		if(HR_flag==1)     //�������
		{
			//��ǰ����
		OLED_ShowHanzi(0,0,16);
		OLED_ShowHanzi(16,0,17);			
		OLED_ShowHanzi(32,0,4);
		OLED_ShowHanzi(48,0,5);
		memset(Oled_array,0,sizeof(Oled_array));
		sprintf(Oled_array,"%d ",HR);
			if(HR)
		    OLED_ShowStr(64,0,Oled_array,16);
			else
				OLED_ShowChar(64,0,'-',16);
		//�������	
		OLED_ShowHanzi(0,2,18);
		OLED_ShowHanzi(16,2,19);
		memset(Oled_array,0,sizeof(Oled_array));
		sprintf(Oled_array,"%d ",high_hr);
		OLED_ShowStr(32,2,Oled_array,16);
		//�������
		OLED_ShowHanzi(64,2,18);
		OLED_ShowHanzi(80,2,20);
		memset(Oled_array,0,sizeof(Oled_array));
		sprintf(Oled_array,"%d ",low_hr);
		OLED_ShowStr(96,2,Oled_array,16);
		}
		if(HR_flag==2)     //�쳣����
		{
			memset(Oled_array,0,sizeof(Oled_array));
		  sprintf(Oled_array,"SDNN:%.2f",SDNN);
			OLED_ShowStr(0,1,Oled_array,8);
			memset(Oled_array,0,sizeof(Oled_array));
		  sprintf(Oled_array,"QT:%d",QT);
			OLED_ShowStr(0,2,Oled_array,8);
			memset(Oled_array,0,sizeof(Oled_array));
		  sprintf(Oled_array,"ARR:%d",ARR);
			OLED_ShowStr(0,3,Oled_array,8);
			if(HR!=0)
		 {
			if(HR>120)
			 {
					hr_flag=1;
			 }
			else if(HR<50)
			 {
		 			hr_flag=2;		
			 }
			else if(ARR)
			{
					hr_flag=3;						
			}
		 }
	 }
	}
  if(Mode_flag==3)               //������ʾ
	{	 
		if(use_num==3)
		{
			re_flag++;
			if(re_flag>1)re_flag=0;
			OLED_Clear();
		}
		if(re_flag)
		{
		 OLED_ShowHanzi(0,0,31);
		 OLED_ShowHanzi(16,0,32);	
		 OLED_ShowHanzi(32,0,33);
		 OLED_ShowHanzi(48,0,35);	
		 OLED_ShowHanzi(64,0,36);
		 OLED_ShowHanzi(80,0,37);
		 OLED_ShowHanzi(112,0,46);
			
		 OLED_ShowHanzi(0,2,31);
		 OLED_ShowHanzi(16,2,32);	
		 OLED_ShowHanzi(32,2,34);
		 OLED_ShowHanzi(48,2,35);	
		 OLED_ShowHanzi(64,2,36);
		 OLED_ShowHanzi(80,2,37);	
		 OLED_ShowHanzi(112,2,46);			
		}
		else
		{
		 OLED_ShowHanzi(0,0,38);
		 OLED_ShowHanzi(16,0,35);	
		 OLED_ShowHanzi(32,0,4);
		 OLED_ShowHanzi(48,0,39);	
		 OLED_ShowHanzi(64,0,44);
		 OLED_ShowHanzi(80,0,45);	
		 OLED_ShowHanzi(112,0,47);
			
			
		 OLED_ShowHanzi(0,2,40);
		 OLED_ShowHanzi(16,2,41);
		 OLED_ShowStr(32,2,"ST-T",16);
		 OLED_ShowHanzi(64,2,4);
		 OLED_ShowHanzi(80,2,39);	
		 OLED_ShowHanzi(112,2,46);
		}
	}	
}
 else
 {
	 OLED_ShowHanzi(40,0,24);
	 OLED_ShowHanzi(56,0,25);
	 OLED_ShowHanzi(72,0,26);
	 OLED_ShowHanzi(32,2,27);
	 OLED_ShowHanzi(48,2,28);
	 OLED_ShowHanzi(64,2,29);
	 OLED_ShowHanzi(80,2,30);
 }
/*-------------------------------------------------�������---------------------------------------------------*/
		if(Pre_flag){
			old_high=now_high;
		  now_high=pressure_to_altitude();
			Imp_high=fabs(now_high-old_high);
	    Pre_flag=0;
	}
    if(Acc_flag){
			      /* ��ȡ ��̬ */
		atk_ms6050_dmp_get_data(&pitch,&roll,&yaw);
					  /* ��ȡ ���ٶ� */
	  atk_ms6050_get_accelerometer(&ax, &ay, &az);	
			     /* ��̬���� */
		{
		Realy_ax=ax-sin(pitch);
		Realy_ay=ay+9.8f*cos(pitch)*sin(roll);
		Realy_az=az-cos(pitch)*cos(roll);
		ax_filt = alpha * ax_filt + (1 - alpha) * Realy_ax;
    ay_filt = alpha * ay_filt + (1 - alpha) * Realy_ay;
    az_filt = alpha * az_filt + (1 - alpha) * Realy_az;
		SVM=sqrt(ax_filt*ax_filt + ay_filt*ay_filt+ + az_filt*az_filt);
		}		
		if(Max_acc<SVM){Danger_flag=1;}
    if(Danger_flag){
			pre_high=pressure_to_altitude();
		}
		Acc_flag=0;
	 }
		if(fabs(old_high-pre_high)>40&&Danger_flag)
		{
			Diedao_flag=1;
			Danger_flag=0;
		}
		else
		{
			Danger_flag=0;
		}
	if(Diedao_flag==1)
	{
     OLED_ShowStr(0,1,"DIEDAO",8);
	}	
	if(hr_flag==1)
	{
		hr_flag=0;
		temp_time.ui8Year=rtc_date_struct.Year+2000;      // 1970~2038
		temp_time.ui8Month=rtc_date_struct.Month;       // 1~12
		temp_time.ui8DayOfMonth=rtc_date_struct.Date;  // 1~31
		temp_time.ui8Hour=rtc_time_struct.Hours;        // 0~23
		temp_time.ui8Minute=rtc_time_struct.Minutes;      // 0~59
		temp_time.ui8Second=rtc_time_struct.Seconds;      // 0~59
		covBeijing2UnixTimeStp(&temp_time);
		Stor_array[0]=unix|0xff;
		Stor_array[1]=(unix>>8)|0xff;
		Stor_array[2]=(unix>>16)|0xff;
		Stor_array[3]=(unix>>24)|0xff;
		Stor_array[4]=HR;
		EEPROM_Read(&iic3,EEPROM_DEV_ADDR3,EEPROM_HIGH_ADDR,addr_temp,2);
		addr=(addr_temp[0]<<8)|addr_temp[1];
		EEPROM_Write(&iic3,EEPROM_DEV_ADDR3,addr,Stor_array,5);
		addr_temp[1]=(addr)|0xff;
		addr_temp[0]=(addr>>8)|0xff;
		EEPROM_Write(&iic3,EEPROM_DEV_ADDR3,EEPROM_HIGH_ADDR,addr_temp,2);
	}
}

  /* USER CODE END 3 */
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)/* 5ms��һ���ж� */
{
	static uint16_t count=0,sys_count=0,dog_count=50,hr_count=0;
	if(htim->Instance==TIM3){
		Acc_flag=1;
		if(++count>100)
		{
		  Pre_flag=1;	
      count=0;			
		}
		if(all_flag==1)
		{
			if(++hr_count>6000)
		{
		  stop_flag=1;	
      hr_count=0;			
		}
		}
		else
		{
			hr_count=0;
		}
		dog_count--;
		if(Uart1_FeedDog==1){dog_count=50;}
		if(dog_count<10){
			memset(Uart1_rx_data_array,0,sizeof(Uart1_rx_data_array));
			Uart1_rx_data_length=0;
		}
		if(++sys_count>200)
		{
			sys_count=0;
			System_Delay++;
			if(System_Delay>60)
				{
							System_Delay=0;
				}
			}
	  Key_Tick();
	}

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
		while(Error_flag==1)
		{
			OLED_ShowStr(0,0,"error-1",8);
		}
		while(Error_flag==2)
		{
			OLED_ShowStr(0,0,"error-2",8);
		}
		while(Error_flag==3)
		{
			OLED_ShowStr(0,0,"error-3",8);
		}
		while(Error_flag==4)
		{
			OLED_ShowStr(0,0,"error-4",8);
		}
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
